/* globals */
#include "globs.h"

globs_t globs={~0};
