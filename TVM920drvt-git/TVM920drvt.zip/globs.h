#ifndef GLOBSH
#define GLOBSH


#include <stdint.h>
typedef struct {
	uint32_t AxisMotionMute;


} globs_t;


extern globs_t globs;
#endif

